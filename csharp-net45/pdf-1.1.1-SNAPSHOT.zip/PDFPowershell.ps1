Clear-Host
[Reflection.Assembly]::LoadFile("C:\Temp\Transfer\20180207\PowerShell Test\RestSharp.dll")
[Reflection.Assembly]::LoadFile("C:\Temp\Transfer\20180207\PowerShell Test\Newtonsoft.Json.dll")
[Reflection.Assembly]::LoadFile("C:\Temp\Transfer\20180207\PowerShell Test\Sphereon.SDK.Pdf.dll")

[Sphereon.SDK.Pdf.Api.DebugHelper]::AttachDebugger()


$apiInstance = [Sphereon.SDK.Pdf.Api.Conversion2PDFApi]::new()
$apiInstance.Configuration.AccessToken = "d61d127f-1215-3314-bef0-b9e2dbf4f51e"


$Script:settings = [Sphereon.SDK.Pdf.Model.ConversionSettings]::new()
$storageLocationIn = [Sphereon.SDK.Pdf.Model.StorageLocation]::new()
$storageLocationIn.ContainerId = "b82ea461-6854-459e-ba27-deefce16c95e"
$storageLocationIn.FolderPath = "input"

$storageLocationRe = [Sphereon.SDK.Pdf.Model.StorageLocation]::new()
$storageLocationRe.ContainerId = "b82ea461-6854-459e-ba27-deefce16c95e"
$storageLocationRe.FolderPath = "result"

$inputSettings = [Sphereon.SDK.Pdf.Model.InputSettings]::new($null, $storageLocationIn)
$resultSettings = [Sphereon.SDK.Pdf.Model.ResultSettings]::new($null, $storageLocationRe, $null, "PDF")

$settings.OcrMode = [Sphereon.SDK.Pdf.Model.ConversionSettings+OcrModeEnum]::AUTO
$settings.QualityFactor = 10
$settings.ContainerConversion = [Sphereon.SDK.Pdf.Model.ConversionSettings+ContainerConversionEnum]::ALL
$settings.Engine = [Sphereon.SDK.Pdf.Model.ConversionSettings+EngineEnum]::ADVANCED
$settings.Version = "_17"
$settings.Input = $inputSettings
$settings.Result = $resultSettings

Try 
{
	$jobResponse = $apiInstance.CreateJob($settings)
	Write-Host $jobResponse
}
Catch
{
	$ErrorMessage = $_.Exception.Message
	Write-Error $ErrorMessage
}
	